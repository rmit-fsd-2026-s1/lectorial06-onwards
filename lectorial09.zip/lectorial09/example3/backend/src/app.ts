import "reflect-metadata";
import express from "express";
import cors from "cors";
import petRoutes from "./routes/pet.routes";
import profileRoutes from "./routes/profile.routes";

const app = express();

app.use(cors());
app.use(express.json());
app.use("/api/pet", petRoutes);
app.use("/api/profile", profileRoutes);

export default app;

import "reflect-metadata";
import { DataSource, DataSourceOptions } from "typeorm";
import { Profile } from "./entity/Profile";
import { Pet } from "./entity/Pet";

const isTesting = process.env.NODE_ENV === "test";

const sqliteConfig: DataSourceOptions = {
  type: "sqlite",
  database: isTesting ? ":memory:" : "database.sqlite",
  entities: [Profile, Pet],
  synchronize: true,
  logging: false,
};

const mssqlConfig: DataSourceOptions = {
  type: "mssql",
  host: "dipto-database.cn2ems8y2mfe.ap-southeast-2.rds.amazonaws.com",
  username: "diptoStudent",
  password: "COSC2758-2026@!",
  database: "diptoStudent",
      options: {
        encrypt: false, // Use this for Azure SQL Database
        //trustedConnection: false // Use this for Windows Authentication (if applicable)
    },
  // synchronize: true will automatically create database tables based on entity definitions
  // and update them when entity definitions change. This is useful during development
  // but should be disabled in production to prevent accidental data loss.
  synchronize: true, 
  logging: false, // Enable logging for debugging purposes
  entities: [Profile, Pet], // Register the Tutorial entity with TypeORM, allowing it to manage the corresponding database table and perform CRUD operations based on the defined schema.
  migrations: [],
  subscribers: [],
};

export const AppDataSource = new DataSource(
  isTesting ? sqliteConfig : mssqlConfig
);

__turbopack_load_page_chunks__("/", [
  "static/chunks/node_modules_next_dist_09f980de._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_axios_lib_9aa2336a._.js",
  "static/chunks/node_modules_1b7400a8._.js",
  "static/chunks/[root of the server]__4514ce75._.js",
  "static/chunks/src_pages_index_5771e187._.js",
  "static/chunks/src_pages_index_125a5307._.js"
])

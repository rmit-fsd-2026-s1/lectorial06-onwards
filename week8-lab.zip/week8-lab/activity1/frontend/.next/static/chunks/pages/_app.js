__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_2f8b308d._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_1b7400a8._.js",
  "static/chunks/[root of the server]__659f318b._.js",
  "static/chunks/src_styles_globals_4738091e.css",
  "static/chunks/src_pages__app_5771e187._.js",
  "static/chunks/src_pages__app_aeebcd07._.js"
])
